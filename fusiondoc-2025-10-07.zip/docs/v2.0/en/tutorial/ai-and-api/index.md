---
title: "AI and API"
folder_position: 4
---

# AI and API

This section describes components for interacting with APIs and the integrated AI features powered by Google Gemini. Learn how to create REST clients, document your endpoints, and power up your documentation with artificial intelligence.
