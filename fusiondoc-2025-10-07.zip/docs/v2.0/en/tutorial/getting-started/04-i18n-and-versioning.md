---
title: "Internationalization and Versioning"
position: 4
---

# Internationalization (i18n) and Versioning

The platform natively supports managing multiple languages and versions of your documentation. This allows you to serve the right content to your global audience and maintain documentation for older versions.

## Configuration in `config.json`

The main control over these features is located in `config.json`.

### i18n Configuration
```json
"i18n": {
    "defaultLang": "en",
    "languages": [
        { "code": "es", "name": "Español" },
        { "code": "en", "name": "English" }
    ]
}
```
- `defaultLang`: The language that will be loaded by default if none is selected.
- `languages`: An array of available languages. The `code` must match the folder name.

**Note:** Internationalization is always enabled. The language switcher will automatically appear when multiple languages are configured.

### Versioning Configuration
```json
"version": {
    "defaultVersion": "v2.0",
    "versions": ["v2.0", "v1.0"]
}
```
- `defaultVersion`: The version that will be loaded by default.
- `versions`: An array of all available versions, in the order you want them to appear.

**Note:** Versioning is always enabled. The version switcher will automatically appear when multiple versions are configured.

## Project Structure

How you organize your files in the `docs/` folder is crucial for these features to work correctly. Each folder representing a main section or subsection should contain an `index.md` file to serve as the landing page for that section.

### Scenario 1: Single Language, Single Version
For basic projects with one language and one version, the structure is flat.
```bash
docs/
├── index.md            # Main site page
├── page-1.md
├── page-2.md
└── subfolder/
    ├── index.md        # Main page for 'subfolder'
    └── page-3.md
```

### Scenario 2: Multiple Versions
When you have multiple versions, the first subdirectory must be the version name.
```bash
docs/
├── v1.0/
│   ├── index.md        # Main page for v1.0
│   ├── page-1.md
│   └── page-2.md
└── v2.0/
    ├── index.md        # Main page for v2.0
    ├── page-1.md
    └── new-features.md
```

### Scenario 3: Multiple Languages
When you have multiple languages, the first subdirectory must be the language code.
```bash
docs/
├── es/
│   ├── index.md        # Main page in Spanish
│   ├── pagina-1.md
│   └── pagina-2.md
└── en/
    ├── index.md        # Main page in English
│   ├── page-1.md
    └── page-2.md
```

### Scenario 4: i18n and Versioning Enabled (Recommended)
The structure must be `version/language/content`. This provides maximum flexibility.
```bash
docs/
├── v1.0/
│   ├── es/
│   │   ├── index.md    # Main page for v1.0 in Spanish
│   │   └── pagina-1.md
│   └── en/
│       ├── index.md    # Main page for v1.0 in English
│       └── page-1.md
└── v2.0/
    ├── es/
    │   ├── index.md    # Main page for v2.0 in Spanish
    │   ├── pagina-1.md
    │   └── caracteristicas-nuevas.md
    └── en/
        ├── index.md    # Main page for v2.0 in English
        ├── page-1.md
        └── new-features.md
```

## UI Translation (`UI_TEXT`)

In addition to translating your Markdown content, you can translate the fixed UI texts (buttons, labels, etc.) in `config.json`, within the `uiText` object.

```typescript
export const UI_TEXT = {
    es: {
        // ...
        searchPlaceholder: 'Buscar',
        editThisPage: 'Editar esta página',
        // ...
    },
    en: {
        // ...
        searchPlaceholder: 'Search',
        editThisPage: 'Edit this page',
        // ...
    }
};
```
Add or modify the keys for each language you have configured in `I18N_CONFIG`.