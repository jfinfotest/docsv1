---
title: "Basic Components"
folder_position: 2
---

This section covers the foundational components for structuring your documentation content.
