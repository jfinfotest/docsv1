---
title: "Part 1: Introduction"
author: "The Spring Boot Team"
date: "2024-09-01"
folder_position: 1
---

# Part 1: Introduction and Fundamentals

In this first part of the tutorial, we will lay the groundwork for our journey with Spring Boot. You will learn what Spring Boot is, how to set up your development environment, and create your first "Hello World" application.