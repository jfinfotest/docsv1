---
title: "Componentes Básicos"
folder_position: 2
---

Esta sección cubre los componentes fundamentales para estructurar el contenido de tu documentación.
