---
title: "IA y API"
folder_position: 4
---

# IA y API

Esta sección describe los componentes para interactuar con APIs y las funciones de IA integradas, impulsadas por Google Gemini. Aprende a crear clientes REST, documentar tus endpoints y potenciar tu documentación con inteligencia artificial.
