---
title: "Parte 1: Introducción"
author: "El Equipo de Spring Boot"
date: "2024-09-01"
folder_position: 1
---

# Parte 1: Introducción y Fundamentos

En esta primera parte del tutorial, sentaremos las bases para nuestro viaje con Spring Boot. Aprenderás qué es Spring Boot, cómo configurar tu entorno de desarrollo y crearás tu primera aplicación "Hola Mundo".