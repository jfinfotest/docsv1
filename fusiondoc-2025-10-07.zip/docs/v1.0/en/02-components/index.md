---
title: "Components"
folder_position: 2
---

# Component Guide

This section provides a quick reference for all the custom Markdown components available on the platform.