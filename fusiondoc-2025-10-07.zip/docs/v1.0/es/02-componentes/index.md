---
title: "Componentes"
folder_position: 2
---

# Guía de Componentes

Esta sección proporciona una referencia rápida para todos los componentes de Markdown personalizados disponibles en la plataforma.