import{b as r}from"./_baseUniq-3441c19b.js";function n(n){return r(n,4)}export{n as c};
