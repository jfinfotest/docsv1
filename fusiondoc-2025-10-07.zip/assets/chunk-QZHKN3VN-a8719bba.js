var t;import{_ as s}from"./charts-7e225b83.js";var r=(s(t=class{constructor(t){this.init=t,this.records=this.init()}reset(){this.records=this.init()}},"ImperativeState"),t);export{r as I};
